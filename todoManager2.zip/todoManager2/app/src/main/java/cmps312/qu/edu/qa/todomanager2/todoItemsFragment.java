package cmps312.qu.edu.qa.todomanager2;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;


public class todoItemsFragment extends Fragment{
    private static final String DIALOG_DATE = "DIALOG_DATE";
    private static final String DIALOG_TIME = "DIALOG_TIME";
    private static final String TITLE = "TITLE";
    private static final String PRIORITY_LEVEL = "NOT_DEFINED";
    private static final String STATUS = "NOT_DEFINED";
    public static final int REQUEST_DATE = 0;
    public static final int REQUEST_TIME = 0;
    private todoItems todoItems;
    private EditText editTextTile;
    private RadioGroup radioGroupStatus, radioGroupPriority;
    private Button buttonDate, buttonTime;
    private TextView textViewDate, textViewTime;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        todoItems = new todoItems();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState){
        View v = inflater.inflate(R.layout.todo_items_fragment_layout,container,false);
        editTextTile = (EditText) v.findViewById(R.id.editText);
        editTextTile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //left blank
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                todoItems.setTitle(charSequence.toString());

                //.putCharSequence(TITLE,charSequence);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //left black
            }
        });

        radioGroupPriority = (RadioGroup) v.findViewById(R.id.radioGroupPriority);
        radioGroupPriority.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int position) {
               switch (position){
                case R.id.low  : todoItems.setPriority(0);
                    break;
                case R.id.med  : todoItems.setPriority(1);
                    break;
                case R.id.high : todoItems.setPriority(2);
                }
                //savedInstanceState.putInt(PRIORITY_LEVEL,position);
            }
        });
        radioGroupStatus = (RadioGroup) v.findViewById(R.id.radioGroupStatus);
        radioGroupStatus.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int position) {
                switch (position) {
                    case R.id.done: todoItems.setStatus(true);
                        break;
                    case R.id.notDone: todoItems.setStatus(false);
                }
                //savedInstanceState.putInt(STATUS,position);
            }
        });
        textViewDate = (TextView) v.findViewById(R.id.date_format_label) ;
        buttonDate = (Button) v.findViewById(R.id.date_button);
        buttonDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                DatePickerFragment dialog = DatePickerFragment.newInstance(todoItems.getDate());
                dialog.setTargetFragment(todoItemsFragment.this,REQUEST_DATE);
                dialog.show(fragmentManager,DIALOG_DATE);
                textViewDate.setText(dialog.toString()); //check this
            }
        });

        textViewTime = (TextView) v.findViewById(R.id.time_format_label);
        buttonTime = (Button) v.findViewById(R.id.time_button);
        buttonTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                TimePickerFragment dialog = TimePickerFragment.newInstance(todoItems.getTime());
               // dialog.setTargetFragment(todoItemsFragment.this,REQUEST_DATE);
                // dialog.show(fragmentManager,DIALOG_TIME);
                textViewTime.setText(dialog.toString()); //check this
            }
        });

        return v;
    }


     public static todoItemsFragment newInstanceTitle(String title){
        Bundle bundle = new Bundle();
        bundle.putCharSequence(TITLE,title);
        todoItemsFragment fragment = new todoItemsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }
    public static todoItemsFragment newInstanceStatus(int status){
        Bundle bundle = new Bundle();
        bundle.putInt(STATUS,status);
        todoItemsFragment fragment = new todoItemsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }
    public static todoItemsFragment newInstancePriority(int priority){
        Bundle bundle = new Bundle();
        bundle.putInt(PRIORITY_LEVEL,priority);
        todoItemsFragment fragment = new todoItemsFragment();
        fragment.setArguments(bundle);
        return fragment;
    }

}
