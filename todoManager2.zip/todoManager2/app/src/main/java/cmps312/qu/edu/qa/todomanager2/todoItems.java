package cmps312.qu.edu.qa.todomanager2;

import java.util.Date;

public class todoItems {

    private String title;
    private boolean status;
    private int priority;
    private Date date;
    private Date time;

    public todoItems() { //initial values of attributes
        this.title = "";
        this.status = false;
        this.priority = 0;
        this.date = new Date();
        this.time = new Date();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}
